import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TopupShop } from './components/TopupShop';
import { TrackOrder } from './components/TrackOrder';
import { ReviewsSection } from './components/ReviewsSection';
import { AdminPanel } from './components/AdminPanel';
import { Footer } from './components/Footer';
import { Order, INITIAL_ORDERS, PAYMENT_CONFIG } from './data/packages';
import { MessageCircle } from 'lucide-react';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('shop');
  const [orders, setOrders] = useState<Order[]>(() => {
    const savedOrders = localStorage.getItem('mtc_orders_list');
    if (savedOrders) {
      try {
        return JSON.parse(savedOrders);
      } catch (e) {
        return INITIAL_ORDERS;
      }
    }
    return INITIAL_ORDERS;
  });

  // Keep local storage in sync whenever orders change
  useEffect(() => {
    localStorage.setItem('mtc_orders_list', JSON.stringify(orders));
  }, [orders]);

  const handleOrderPlaced = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    // Optionally trigger a gentle audio sound or state updates
  };

  const handleUpdateStatus = (orderId: string, status: Order['status']) => {
    setOrders(prev => prev.map(o => {
      if (o.orderId === orderId) {
        return { ...o, status };
      }
      return o;
    }));
  };

  const handleClearDemoOrders = () => {
    setOrders([]);
    localStorage.removeItem('mtc_orders_list');
  };

  const handleResetToDefault = () => {
    setOrders(INITIAL_ORDERS);
    localStorage.setItem('mtc_orders_list', JSON.stringify(INITIAL_ORDERS));
  };

  const scrollToShopSection = () => {
    setActiveTab('shop');
    setTimeout(() => {
      const el = document.getElementById('shop-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  const pendingCount = orders.filter(o => o.status === 'Pending').length;

  return (
    <div className="min-h-screen flex flex-col bg-[#0b0f19] text-[#f1f5f9] selection:bg-orange-500 selection:text-slate-950">
      
      {/* Dynamic Header */}
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        pendingCount={pendingCount} 
      />

      {/* Main Container View based on activeTab */}
      <main className="flex-grow">
        {activeTab === 'shop' && (
          <div>
            <Hero onScrollToShop={scrollToShopSection} />
            <TopupShop onOrderPlaced={handleOrderPlaced} />
          </div>
        )}

        {activeTab === 'track' && (
          <TrackOrder orders={orders} />
        )}

        {activeTab === 'reviews' && (
          <ReviewsSection />
        )}

        {activeTab === 'admin' && (
          <AdminPanel 
            orders={orders} 
            onUpdateStatus={handleUpdateStatus} 
            onClearDemoOrders={handleClearDemoOrders}
            onResetToDefault={handleResetToDefault}
          />
        )}
      </main>

      {/* Persistent Floating WhatsApp Help action button */}
      <a
        href={PAYMENT_CONFIG.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 right-5 z-40 p-3.5 sm:p-4 rounded-full bg-emerald-500 text-slate-950 shadow-xl shadow-emerald-500/30 hover:scale-110 active:scale-95 transition-all flex items-center justify-center group"
        title="Chat on WhatsApp with Manik TopUp Center"
      >
        <MessageCircle className="w-6 h-6 fill-slate-950" />
        {/* Pulsing indicator tag */}
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-300"></span>
        </span>
      </a>

      {/* Footer */}
      <Footer />

    </div>
  );
};

export default App;
