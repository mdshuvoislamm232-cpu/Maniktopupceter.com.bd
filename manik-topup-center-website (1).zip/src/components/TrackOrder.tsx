import React, { useState } from 'react';
import { Order, PAYMENT_CONFIG } from '../data/packages';
import { Search, CheckCircle2, Clock, Loader2, XCircle, RefreshCw, MessageSquare } from 'lucide-react';

interface TrackOrderProps {
  orders: Order[];
}

export const TrackOrder: React.FC<TrackOrderProps> = ({ orders }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedOrders, setSearchedOrders] = useState<Order[]>(orders.slice(0, 5)); // show latest 5 by default
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      // reset to general view
      setSearchedOrders(orders.slice(0, 5));
      setHasSearched(false);
      return;
    }

    const query = searchQuery.trim().toLowerCase();
    const results = orders.filter(
      o => o.orderId.toLowerCase().includes(query) || 
           o.uid.toLowerCase().includes(query) ||
           o.senderNumber.includes(query)
    );

    setSearchedOrders(results);
    setHasSearched(true);
  };

  const handleReset = () => {
    setSearchQuery('');
    setSearchedOrders(orders.slice(0, 5));
    setHasSearched(false);
  };

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5" /> Delivered
          </span>
        );
      case 'Processing':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Loader2 className="w-3.5 h-3.5 animate-spin" /> Processing
          </span>
        );
      case 'Rejected':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-red-500/10 text-red-400 border border-red-500/20">
            <XCircle className="w-3.5 h-3.5" /> Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Clock className="w-3.5 h-3.5" /> Pending Verify
          </span>
        );
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Header */}
      <div className="text-center max-w-xl mx-auto mb-8">
        <h2 className="text-3xl font-black text-white uppercase font-gaming tracking-tight">
          Track Your Top-Up Status
        </h2>
        <p className="text-slate-400 text-xs sm:text-sm mt-1">
          Enter your Order ID (e.g. MTC-1234) or Player UID to check live delivery updates.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-800 shadow-xl mb-8">
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Order ID or Free Fire UID..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 tracking-wide transition-colors placeholder:text-slate-600"
            />
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 sm:flex-none px-6 py-3 bg-orange-500 hover:bg-orange-600 text-slate-950 font-gaming font-bold tracking-wide rounded-xl text-sm transition-all shadow"
            >
              Search
            </button>
            
            {hasSearched && (
              <button
                type="button"
                onClick={handleReset}
                title="Reset view"
                className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-xl transition-all"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
          </div>
        </form>

        <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500 px-1">
          <span>Search history is local to your browser session.</span>
          <span>Delivery timeline: 2-5 min</span>
        </div>
      </div>

      {/* Results Container */}
      <div className="space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            {hasSearched ? `Search Results (${searchedOrders.length})` : 'Recent Top-Up Logs'}
          </h3>
          <span className="text-xs text-emerald-500 flex items-center gap-1 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Auto Updating System
          </span>
        </div>

        {searchedOrders.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-sm">
            <p>No matching orders found for <strong className="text-white">"{searchQuery}"</strong>.</p>
            <p className="text-xs text-slate-500 mt-1">Please make sure you entered the correct numeric code or check your internet connectivity.</p>
            <button 
              onClick={handleReset} 
              className="mt-3 text-xs text-orange-400 hover:underline"
            >
              Clear filter and show latest requests
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {searchedOrders.map((order) => (
              <div 
                key={order.orderId}
                className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 sm:p-5 hover:border-slate-700 transition-all shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                {/* Left side info */}
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-orange-400 text-sm bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                      {order.orderId}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      UID: <strong className="text-white">{order.uid}</strong>
                    </span>
                  </div>

                  <div className="text-base font-gaming font-bold text-white tracking-wide">
                    {order.packageName} <span className="text-xs font-sans font-normal text-slate-400"> (৳{order.price})</span>
                  </div>

                  <div className="text-[11px] text-slate-500 flex items-center gap-3 flex-wrap">
                    <span>TrxID: <span className="font-mono text-slate-400">{order.trxId.slice(0, 4)}••••{order.trxId.slice(-3)}</span></span>
                    <span>•</span>
                    <span>Sender: <span className="font-mono text-slate-400">{order.senderNumber.slice(0, 5)}••••••</span></span>
                    <span>•</span>
                    <span>{order.timestamp}</span>
                  </div>
                </div>

                {/* Right side Status & actions */}
                <div className="flex sm:flex-col items-center sm:items-end justify-between pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-800/80 gap-2 shrink-0">
                  {getStatusBadge(order.status)}
                  
                  {order.status === 'Pending' && (
                    <span className="text-[10px] text-slate-500 italic block text-right">
                      Verifying bKash status...
                    </span>
                  )}
                  {order.status === 'Completed' && (
                    <span className="text-[10px] text-emerald-500 block text-right font-medium">
                      ✓ UID Disbursed
                    </span>
                  )}
                </div>

              </div>
            ))}
          </div>
        )}

      </div>

      {/* Quick Customer care banner */}
      <div className="mt-12 bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 text-center max-w-2xl mx-auto">
        <MessageSquare className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
        <h4 className="text-base font-bold text-white">Order taking longer than 10 minutes?</h4>
        <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
          Sometimes automated bKash server responses take slightly longer. Do not worry! Send your <strong>Order ID</strong> directly on WhatsApp for manual priority push.
        </p>
        <a
          href={PAYMENT_CONFIG.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold tracking-wide transition-all shadow"
        >
          💬 Message WhatsApp: {PAYMENT_CONFIG.whatsappNumber}
        </a>
      </div>

    </div>
  );
};
