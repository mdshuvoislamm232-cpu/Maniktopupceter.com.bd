import React from 'react';
import { Order, PAYMENT_CONFIG } from '../data/packages';
import { Shield, Check, X, Clock, Database, AlertCircle, RefreshCw } from 'lucide-react';

interface AdminPanelProps {
  orders: Order[];
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
  onClearDemoOrders?: () => void;
  onResetToDefault?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ 
  orders, 
  onUpdateStatus, 
  onClearDemoOrders,
  onResetToDefault 
}) => {
  const pendingOrders = orders.filter(o => o.status === 'Pending');
  const otherOrders = orders.filter(o => o.status !== 'Pending');

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Disclaimer / Top warning */}
      <div className="bg-purple-950/40 border border-purple-500/30 rounded-2xl p-6 mb-8 text-left relative overflow-hidden">
        <div className="absolute top-0 left-0 bottom-0 w-1 bg-purple-500"></div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-purple-400 mb-1">
              <Shield className="w-4 h-4" /> ManikTopupCenter Owner Live Console
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-gaming">
              Backend Fulfillment Simulator
            </h2>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl">
              This interactive admin simulation allows you to test top-up requests placed on the main store. Verify <strong>bKash TrxID</strong> and trigger state switches to prove complete state continuity.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onResetToDefault && (
              <button
                onClick={onResetToDefault}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold flex items-center gap-1 border border-slate-700"
                title="Restore default mock items"
              >
                <RefreshCw className="w-3 h-3" /> Factory Reset
              </button>
            )}
            {onClearDemoOrders && (
              <button
                onClick={onClearDemoOrders}
                className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-xs font-semibold border border-red-500/20"
              >
                Clear All Logs
              </button>
            )}
          </div>
        </div>

        {/* Info stats bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-4 border-t border-purple-500/20">
          <div className="bg-slate-950/50 p-2.5 rounded-lg border border-purple-500/10">
            <span className="text-[10px] text-slate-400 block uppercase">Total Captured</span>
            <span className="text-lg font-bold font-mono text-white">{orders.length}</span>
          </div>
          <div className="bg-slate-950/50 p-2.5 rounded-lg border border-purple-500/10">
            <span className="text-[10px] text-slate-400 block uppercase">Pending Action</span>
            <span className="text-lg font-bold font-mono text-amber-400">{pendingOrders.length}</span>
          </div>
          <div className="bg-slate-950/50 p-2.5 rounded-lg border border-purple-500/10">
            <span className="text-[10px] text-slate-400 block uppercase">Completed Delivery</span>
            <span className="text-lg font-bold font-mono text-emerald-400">
              {orders.filter(o => o.status === 'Completed').length}
            </span>
          </div>
          <div className="bg-slate-950/50 p-2.5 rounded-lg border border-purple-500/10">
            <span className="text-[10px] text-slate-400 block uppercase">bKash Active Gateway</span>
            <span className="text-xs font-bold font-mono text-pink-400 truncate block mt-1">{PAYMENT_CONFIG.bkashNumber}</span>
          </div>
        </div>
      </div>

      {/* Orders Management Grid */}
      <div className="space-y-8">
        
        {/* Section 1: PENDING ORDERS REQUESTS */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-sm font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> Live Verification Queue ({pendingOrders.length})
            </h3>
            <span className="text-[11px] text-slate-500 italic">Orders require TrxID audit</span>
          </div>

          {pendingOrders.length === 0 ? (
            <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-8 text-center text-slate-500 text-sm">
              <Check className="w-8 h-8 text-emerald-500/40 mx-auto mb-2" />
              <p>Queue is empty! All customer bKash payments have been processed.</p>
              <p className="text-xs text-slate-600 mt-0.5">Submit a new topup order from the TopUp Shop tab to test live verification triggers.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingOrders.map((order) => (
                <div 
                  key={order.orderId}
                  className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border-l-4 border-l-amber-500 border-y border-r border-slate-800 rounded-r-xl p-4 sm:p-5 shadow-md flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 flex-1 text-left">
                    {/* Basic Order details */}
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Order Hash</span>
                      <span className="font-mono font-bold text-orange-400">{order.orderId}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{order.timestamp}</span>
                    </div>

                    {/* UID Target */}
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Target Free Fire UID</span>
                      <span className="font-mono font-bold text-white tracking-wider bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800 inline-block">
                        {order.uid}
                      </span>
                    </div>

                    {/* Package Spec */}
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">Item / Value</span>
                      <span className="font-bold text-amber-300 block">{order.packageName}</span>
                      <span className="text-xs text-emerald-400 font-mono font-bold">৳{order.price} BDT</span>
                    </div>

                    {/* Payment Audit */}
                    <div>
                      <span className="text-[10px] uppercase font-bold text-pink-500 block">bKash TrxID details</span>
                      <span className="font-mono text-xs font-bold text-white uppercase tracking-wider block bg-pink-950/40 px-1.5 py-0.5 rounded border border-pink-500/20">
                        {order.trxId}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">From: {order.senderNumber}</span>
                    </div>
                  </div>

                  {/* Actions column */}
                  <div className="pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-800 flex items-center justify-end gap-2 shrink-0">
                    <button
                      onClick={() => onUpdateStatus(order.orderId, 'Processing')}
                      className="px-3 py-1.5 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs font-semibold transition-all"
                      title="Set status to processing"
                    >
                      Process
                    </button>

                    <button
                      onClick={() => onUpdateStatus(order.orderId, 'Completed')}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 transition-all shadow"
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" /> Approve
                    </button>

                    <button
                      onClick={() => onUpdateStatus(order.orderId, 'Rejected')}
                      className="px-2.5 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs font-semibold transition-all"
                      title="Reject bad TrxID"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>


        {/* Section 2: PROCESSED & HISTORY LOGS */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Database className="w-4 h-4 text-slate-500" /> Historical Log Audits ({otherOrders.length})
            </h3>
          </div>

          {otherOrders.length === 0 ? (
            <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-6 text-center text-slate-600 text-xs italic">
              No historical logs available.
            </div>
          ) : (
            <div className="space-y-2.5">
              {otherOrders.map((order) => (
                <div 
                  key={order.orderId}
                  className="bg-slate-900/50 border border-slate-800/80 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="font-mono text-slate-400 w-16">{order.orderId}</span>
                    <span className="text-slate-300 font-medium w-36 truncate">{order.packageName}</span>
                    <span className="font-mono text-slate-400">UID: {order.uid}</span>
                    <span className="text-slate-500 hidden md:inline">• TrxID: {order.trxId}</span>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/50">
                    <span className={`font-semibold px-2 py-0.5 rounded text-[10px] ${
                      order.status === 'Completed' 
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                        : order.status === 'Processing'
                        ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                        : 'bg-red-500/10 text-red-400 border border-red-500/20'
                    }`}>
                      {order.status}
                    </span>

                    {/* Allow toggling back state */}
                    <div className="flex items-center gap-1">
                      {order.status !== 'Completed' && (
                        <button
                          onClick={() => onUpdateStatus(order.orderId, 'Completed')}
                          className="text-[10px] text-emerald-400 hover:underline px-1.5 py-0.5 rounded hover:bg-slate-800"
                        >
                          Mark Completed
                        </button>
                      )}
                      {order.status !== 'Pending' && (
                        <button
                          onClick={() => onUpdateStatus(order.orderId, 'Pending')}
                          className="text-[10px] text-amber-400 hover:underline px-1.5 py-0.5 rounded hover:bg-slate-800"
                        >
                          Revert to Pending
                        </button>
                      )}
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* WhatsApp admin advice config snippet */}
      <div className="mt-12 p-4 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-orange-400 shrink-0" />
          <span>Need real bKash API automation? Connect gateway scripts to webhook endpoints.</span>
        </div>
        <div className="font-mono text-slate-300 bg-slate-950 px-2 py-1 rounded text-[11px]">
          Target Gateway: {PAYMENT_CONFIG.whatsappNumber}
        </div>
      </div>

    </div>
  );
};
