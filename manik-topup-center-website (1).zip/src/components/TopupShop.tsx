import React, { useState } from 'react';
import { TOPUP_PACKAGES, TopupPackage, PAYMENT_CONFIG, Order } from '../data/packages';
import { Sparkles, Check, Copy, AlertCircle, ArrowRight, ShieldAlert } from 'lucide-react';

interface TopupShopProps {
  onOrderPlaced: (order: Order) => void;
}

export const TopupShop: React.FC<TopupShopProps> = ({ onOrderPlaced }) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'diamonds' | 'membership' | 'special'>('all');
  const [uid, setUid] = useState('');
  const [selectedPackage, setSelectedPackage] = useState<TopupPackage | null>(TOPUP_PACKAGES[2]); // Default select 100 Diamonds
  const [senderNumber, setSenderNumber] = useState('');
  const [trxId, setTrxId] = useState('');
  const [copied, setCopied] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);

  const filteredPackages = selectedCategory === 'all' 
    ? TOPUP_PACKAGES 
    : TOPUP_PACKAGES.filter(p => p.category === selectedCategory);

  const handleCopyNumber = () => {
    navigator.clipboard.writeText(PAYMENT_CONFIG.bkashNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!uid.trim()) {
      setErrorMessage('Please enter your valid Free Fire Player UID.');
      return;
    }

    if (uid.replace(/\D/g, '').length < 5) {
      setErrorMessage('Player UID looks too short. Please enter valid numeric UID.');
      return;
    }

    if (!selectedPackage) {
      setErrorMessage('Please select a top-up package from the list.');
      return;
    }

    if (!senderNumber.trim()) {
      setErrorMessage('Please enter the bKash sender mobile number.');
      return;
    }

    if (!trxId.trim()) {
      setErrorMessage('Please enter the bKash Transaction ID (TrxID).');
      return;
    }

    // Generate random 4-digit ID
    const randomId = Math.floor(1000 + Math.random() * 9000);
    const orderId = `MTC-${randomId}`;

    const newOrder: Order = {
      orderId,
      uid: uid.trim(),
      packageId: selectedPackage.id,
      packageName: selectedPackage.name,
      price: selectedPackage.price,
      paymentMethod: 'bKash',
      senderNumber: senderNumber.trim(),
      trxId: trxId.trim().toUpperCase(),
      status: 'Pending',
      timestamp: new Date().toLocaleString(),
    };

    onOrderPlaced(newOrder);
    setSuccessOrder(newOrder);
    // Reset form fields
    setSenderNumber('');
    setTrxId('');
  };

  const resetSuccess = () => {
    setSuccessOrder(null);
  };

  return (
    <div id="shop-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Section Title */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-500 mb-2">
          <Sparkles className="w-4 h-4 animate-spin" style={{ animationDuration: '6s' }} /> Free Fire Direct UID Top-Up
        </div>
        <h2 className="text-3xl sm:text-4xl font-black text-white uppercase font-gaming tracking-tight">
          Select Package & Checkout
        </h2>
        <p className="mt-2 text-slate-400 text-sm">
          No login or password needed! Only Free Fire Player UID required to instantly receive rewards.
        </p>
      </div>

      {successOrder ? (
        /* Order Placed Success Banner */
        <div className="max-w-2xl mx-auto bg-slate-900 border-2 border-emerald-500/40 rounded-2xl p-6 sm:p-8 text-center shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600"></div>
          
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
            <Check className="w-8 h-8 stroke-[2.5]" />
          </div>

          <span className="text-xs font-bold uppercase tracking-widest px-2.5 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 inline-block mb-3">
            Order Submitted Successfully
          </span>

          <h3 className="text-2xl font-bold text-white font-gaming tracking-wide">
            Thank you for ordering at Manik TopUp Center!
          </h3>

          <p className="text-slate-300 text-sm mt-2 max-w-md mx-auto">
            Your top-up request is now in <strong className="text-amber-400">Pending verification</strong> queue. Our automatic system will check the bKash TrxID and dispatch diamonds to your UID in 2-5 minutes.
          </p>

          <div className="mt-6 bg-slate-950 p-4 rounded-xl border border-slate-800 text-left space-y-2 text-sm">
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Order ID:</span>
              <span className="font-mono font-bold text-orange-400">{successOrder.orderId}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Player UID:</span>
              <span className="font-mono font-bold text-white">{successOrder.uid}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Package:</span>
              <span className="font-bold text-amber-300">{successOrder.packageName}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-900">
              <span className="text-slate-400">Amount Paid:</span>
              <span className="font-bold text-emerald-400">৳{successOrder.price}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">bKash TrxID:</span>
              <span className="font-mono text-slate-300">{successOrder.trxId}</span>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={resetSuccess}
              className="w-full sm:w-auto px-6 py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl text-sm transition-all"
            >
              Place Another Order
            </button>

            <a
              href={PAYMENT_CONFIG.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
            >
              💬 WhatsApp Fast Status
            </a>
          </div>

          <p className="mt-4 text-[11px] text-slate-500">
            Tip: You can track this status anytime by navigating to the <strong className="text-slate-400">Track Order</strong> tab.
          </p>
        </div>
      ) : (
        /* Ordering Grid Setup */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT COLUMN: Categories & Packages Grid */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Step 1 & Filter Tabs */}
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-orange-500 text-slate-950 inline-flex items-center justify-center font-bold text-xs">1</span> 
                  Select Category
                </span>
                <span className="text-xs text-slate-500">Showing {filteredPackages.length} packages</span>
              </div>

              <div className="flex flex-wrap gap-1.5 sm:gap-2">
                {(['all', 'diamonds', 'membership', 'special'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${
                      selectedCategory === cat
                        ? 'bg-orange-500 text-slate-950 font-bold shadow'
                        : 'bg-slate-950 text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {cat === 'all' ? '✨ All Items' : cat === 'diamonds' ? '💎 Diamonds' : cat === 'membership' ? '👑 Memberships' : '🎁 Special Offers'}
                  </button>
                ))}
              </div>
            </div>

            {/* Packages Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 sm:gap-4">
              {filteredPackages.map((pkg) => {
                const isSelected = selectedPackage?.id === pkg.id;
                return (
                  <button
                    key={pkg.id}
                    onClick={() => setSelectedPackage(pkg)}
                    className={`relative p-3.5 sm:p-4 rounded-xl text-left transition-all flex flex-col justify-between border cursor-pointer overflow-hidden ${
                      isSelected
                        ? 'bg-gradient-to-b from-slate-900 to-slate-950 border-orange-500 shadow-lg shadow-orange-600/10 scale-[1.02]'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    {/* Package tag ribbon */}
                    {pkg.tag && (
                      <span className={`absolute top-0 right-0 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-bl font-gaming ${
                        pkg.tag === 'Best Seller' || pkg.tag === 'Hot Deal' 
                          ? 'bg-red-500 text-white' 
                          : 'bg-amber-500 text-slate-950'
                      }`}>
                        {pkg.tag}
                      </span>
                    )}

                    {/* Selection Indicator Corner */}
                    {isSelected && (
                      <div className="absolute top-2 left-2 w-2 h-2 rounded-full bg-orange-500 animate-pulse"></div>
                    )}

                    {/* Icon or Graphic Placeholder */}
                    <div className="w-10 h-10 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                      {pkg.iconType === 'card' ? (
                        <span className="text-lg">💳</span>
                      ) : pkg.iconType === 'gift' ? (
                        <span className="text-lg">🎁</span>
                      ) : (
                        <span className="text-lg">💎</span>
                      )}
                    </div>

                    <div>
                      {/* Diamonds Count / Title */}
                      <div className="font-gaming text-base sm:text-lg font-bold text-white leading-tight">
                        {pkg.name}
                      </div>

                      {/* Extra Bonus Indicator */}
                      {pkg.bonus && (
                        <div className="text-[10px] text-amber-400 font-medium mt-0.5">
                          +{pkg.bonus} Extra Bonus
                        </div>
                      )}
                    </div>

                    {/* Price block */}
                    <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-baseline justify-between">
                      <span className="text-[10px] text-slate-500 font-medium">Price</span>
                      <span className="font-gaming text-base sm:text-lg font-bold text-orange-400">
                        ৳{pkg.price}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

          </div>


          {/* RIGHT COLUMN: Player UID Form & Checkout Instruction */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Checkout Dashboard Card */}
            <form onSubmit={handleSubmitOrder} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 relative shadow-xl">
              
              <div className="pb-4 mb-4 border-b border-slate-800 flex items-center justify-between">
                <h3 className="font-gaming text-xl font-bold text-white flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-orange-500 text-slate-950 inline-flex items-center justify-center font-bold text-sm">2</span>
                  Order Configuration
                </h3>
                <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Instant Access
                </span>
              </div>

              {/* Error Message Alert */}
              {errorMessage && (
                <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* UID Input */}
              <div className="space-y-1.5 mb-5">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Player ID / UID <span className="text-red-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={uid}
                    onChange={(e) => setUid(e.target.value)}
                    placeholder="e.g. 7482910385"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500 font-mono tracking-wider transition-colors placeholder:text-slate-600"
                  />
                </div>
                <p className="text-[10px] text-slate-500">
                  Find your Player UID by clicking on your Free Fire avatar in the game.
                </p>
              </div>

              {/* Selected summary subcard */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 mb-5">
                <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold mb-1">
                  Selected Item Summary:
                </div>
                {selectedPackage ? (
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-sm">{selectedPackage.name}</div>
                      <div className="text-[11px] text-slate-400 capitalize">{selectedPackage.category} topup</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-slate-500 line-through font-mono">৳{Math.round(selectedPackage.price * 1.05)}</div>
                      <div className="font-gaming text-lg font-bold text-amber-400 font-mono">৳{selectedPackage.price}</div>
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-slate-500 italic py-1">No package selected yet</div>
                )}
              </div>

              {/* Live bKash Guide Info Block */}
              <div className="bg-[#e2136e]/5 border border-[#e2136e]/20 rounded-xl p-4 mb-5 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-[#e2136e] flex items-center gap-1.5 text-sm">
                    <span className="inline-block w-2 h-2 rounded-full bg-[#e2136e]"></span>
                    bKash Send Money Manual
                  </div>
                  <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#e2136e]/10 text-[#e2136e]">
                    Personal
                  </span>
                </div>

                <ol className="space-y-2 text-slate-300 list-decimal pl-4">
                  <li>
                    Copy bKash number below and open your bKash app.
                  </li>
                  <li>
                    Select <strong>Send Money</strong> option.
                  </li>
                  <li>
                    Enter amount exactly: <strong className="text-white text-sm underline bg-slate-950 px-1 py-0.5 rounded">৳{selectedPackage?.price || 0}</strong>
                  </li>
                  <li>
                    Confirm transfer and paste the transaction TrxID below.
                  </li>
                </ol>

                {/* Copy Number Action box */}
                <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 flex items-center justify-between gap-2">
                  <div className="truncate">
                    <span className="text-[10px] text-slate-500 block uppercase">bKash Personal Number</span>
                    <span className="font-mono text-sm font-bold text-white tracking-wider">{PAYMENT_CONFIG.bkashNumber}</span>
                  </div>

                  <button
                    type="button"
                    onClick={handleCopyNumber}
                    className="shrink-0 px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold flex items-center gap-1 transition-all text-xs cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>


              {/* Verification Parameters */}
              <div className="space-y-4">
                
                {/* Sender Number */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    bKash Sender Number <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={senderNumber}
                    onChange={(e) => setSenderNumber(e.target.value)}
                    placeholder="e.g. 017xxxxxxxx"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors font-mono placeholder:text-slate-600"
                  />
                  <span className="text-[10px] text-slate-500 block">The mobile number from which you sent money.</span>
                </div>

                {/* Transaction ID */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Transaction ID (TrxID) <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={trxId}
                    onChange={(e) => setTrxId(e.target.value)}
                    placeholder="e.g. BKS9A8F7E2B"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500 transition-colors font-mono uppercase tracking-wider placeholder:text-slate-600 placeholder:normal-case"
                  />
                  <span className="text-[10px] text-slate-500 block">10-11 character TrxID found in your bKash SMS or App history.</span>
                </div>

              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="mt-6 w-full py-4 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-gaming font-bold text-base tracking-wider uppercase shadow-lg shadow-orange-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Verify & Place Order</span>
                <ArrowRight className="w-4 h-4 text-slate-950 stroke-[2.5]" />
              </button>

              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-center gap-2 text-[11px] text-slate-400">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                <span>Wrong TrxID will automatically mark order as rejected.</span>
              </div>

            </form>

            {/* Support Note Widget */}
            <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800 text-center">
              <p className="text-xs text-slate-400">
                Having troubles transferring funds or entering TrxID? Direct message on our official WhatsApp setup:
              </p>
              <a
                href={PAYMENT_CONFIG.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 font-bold underline"
              >
                <span>WhatsApp: {PAYMENT_CONFIG.whatsappNumber}</span>
              </a>
            </div>

          </div>

        </div>
      )}

      {/* How To Order Tutorial Anchor Content */}
      <div id="how-to" className="mt-16 pt-12 border-t border-slate-800">
        <div className="text-center max-w-xl mx-auto mb-8">
          <h3 className="text-xl sm:text-2xl font-bold text-white uppercase font-gaming">
            How to Send Money & Buy Diamonds?
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Follow these 3 intuitive steps to secure your premium in-game benefits.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900/60 p-5 rounded-xl border border-slate-800 text-center">
            <div className="w-10 h-10 rounded-full bg-orange-500/10 text-orange-400 flex items-center justify-center font-bold font-gaming text-lg mx-auto mb-3">
              1
            </div>
            <h4 className="font-bold text-white text-sm">Copy Player UID</h4>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Open Free Fire on your mobile, navigate to profile top-left, and hit the copy button next to your unique numeric UID.
            </p>
          </div>

          <div className="bg-slate-900/60 p-5 rounded-xl border border-slate-800 text-center">
            <div className="w-10 h-10 rounded-full bg-[#e2136e]/10 text-[#e2136e] flex items-center justify-center font-bold font-gaming text-lg mx-auto mb-3">
              2
            </div>
            <h4 className="font-bold text-white text-sm">bKash Send Money</h4>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Transfer package amount via Send Money to <span className="text-slate-200 font-mono font-bold">{PAYMENT_CONFIG.bkashNumber}</span>. Do not write anything in reference to avoid delays.
            </p>
          </div>

          <div className="bg-slate-900/60 p-5 rounded-xl border border-slate-800 text-center">
            <div className="w-10 h-10 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold font-gaming text-lg mx-auto mb-3">
              3
            </div>
            <h4 className="font-bold text-white text-sm">Submit TrxID</h4>
            <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
              Paste the transaction ID back into our verification tool above. Our systems authenticate live and disburse your rewards instantly!
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
