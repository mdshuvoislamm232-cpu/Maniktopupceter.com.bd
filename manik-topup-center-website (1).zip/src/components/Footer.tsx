import React from 'react';
import { Flame, MessageCircle, ShieldCheck } from 'lucide-react';
import { PAYMENT_CONFIG } from '../data/packages';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0b0f19] border-t border-slate-900 pt-12 pb-8 mt-auto text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-slate-900">
          
          {/* Brand Col */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-orange-500 rounded-lg text-slate-950 font-bold">
                <Flame className="w-5 h-5 fill-current text-white" />
              </div>
              <span className="font-gaming text-xl font-bold tracking-tight text-white uppercase">
                MANIK TOPUP CENTER
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              The premier destination for automated Free Fire Diamond topups, Weekly & Monthly VIP memberships, and special bundles in Bangladesh. Safe, zero bans, 100% official UID transaction support.
            </p>

            <div className="flex items-center gap-2 text-xs text-emerald-500">
              <ShieldCheck className="w-4 h-4" /> Fully Secure & Regulated bKash Personal Checkout
            </div>
          </div>

          {/* Quick Support channels */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Payment Hotline</h4>
            <div className="text-xs space-y-1.5">
              <p className="text-slate-500">bKash Personal Send Money:</p>
              <p className="text-base font-mono font-bold text-orange-400 select-all">
                {PAYMENT_CONFIG.bkashNumber}
              </p>
              <p className="text-[10px] text-slate-500">Do not include any reference text during transfer.</p>
            </div>
          </div>

          {/* Connect */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Customer Care</h4>
            <p className="text-xs text-slate-400">
              Instant reply guaranteed for any delayed order validation.
            </p>
            <a
              href={PAYMENT_CONFIG.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-400 border border-emerald-500/20 text-xs font-bold transition-all"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>WhatsApp: {PAYMENT_CONFIG.whatsappNumber}</span>
            </a>
          </div>

        </div>

        {/* Disclaimer / Bottom notes */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-600">
          <p>
            © {new Date().getFullYear()} <strong className="text-slate-500 font-gaming tracking-wide">maniktopupcenter</strong>. All respective game assets & graphics belong to Garena Free Fire.
          </p>

          <div className="flex items-center gap-4">
            <span className="hover:underline cursor-pointer">Terms & Conditions</span>
            <span>•</span>
            <span className="hover:underline cursor-pointer">Refund Policy</span>
            <span>•</span>
            <span className="hover:underline cursor-pointer">Delivery Schedule</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
