import React from 'react';
import { Search, MessageCircle, ShieldCheck, UserCog, Flame } from 'lucide-react';
import { PAYMENT_CONFIG } from '../data/packages';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  pendingCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, pendingCount }) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0f172a]/95 backdrop-blur-md border-b border-slate-800">
      {/* Top Banner Ticker */}
      <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-orange-600 text-white text-xs font-medium py-1.5 px-4 text-center flex items-center justify-center gap-2 overflow-hidden shadow-inner">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-300 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-yellow-100"></span>
        </span>
        <span className="truncate">
          🔥 Welcome to <strong>Manik TopUp Center</strong>! Official bKash Personal Number: <span className="underline font-bold text-yellow-200">{PAYMENT_CONFIG.bkashNumber}</span>. Fastest Free Fire ID Topup!
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Logo & Brand */}
          <button 
            onClick={() => setActiveTab('shop')} 
            className="flex items-center gap-2.5 text-left focus:outline-none group"
          >
            <div className="relative p-2.5 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl shadow-lg shadow-orange-600/30 group-hover:scale-105 transition-transform duration-200">
              <Flame className="w-6 h-6 text-white fill-white" />
              <div className="absolute -bottom-1 -right-1 bg-yellow-500 text-[9px] text-slate-950 font-black px-1 rounded">BD</div>
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-gaming text-xl sm:text-2xl font-bold tracking-tight bg-gradient-to-r from-orange-400 via-amber-200 to-white bg-clip-text text-transparent">
                  MANIK TOPUP CENTER
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 font-medium tracking-wide flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400 inline" /> Trusted Free Fire Store
              </p>
            </div>
          </button>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            <button
              onClick={() => setActiveTab('shop')}
              className={`px-4 py-2 rounded-lg font-gaming text-base tracking-wide font-semibold transition-all ${
                activeTab === 'shop'
                  ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              💎 Instant TopUp Shop
            </button>
            <button
              onClick={() => setActiveTab('track')}
              className={`px-4 py-2 rounded-lg font-gaming text-base tracking-wide font-semibold transition-all flex items-center gap-2 ${
                activeTab === 'track'
                  ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Search className="w-4 h-4" /> Track Order
            </button>
            <button
              onClick={() => setActiveTab('reviews')}
              className={`px-4 py-2 rounded-lg font-gaming text-base tracking-wide font-semibold transition-all ${
                activeTab === 'reviews'
                  ? 'bg-orange-500/10 text-orange-400 border border-orange-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              ⭐ Customer Reviews
            </button>
          </nav>

          {/* Quick Support & WhatsApp */}
          <div className="flex items-center gap-2 sm:gap-3">
            <a
              href={PAYMENT_CONFIG.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 bg-emerald-600/20 border border-emerald-500/30 hover:bg-emerald-600 hover:text-white transition-all rounded-lg text-emerald-400 text-xs sm:text-sm font-semibold"
            >
              <MessageCircle className="w-4 h-4 text-emerald-400 group-hover:text-white fill-current" />
              <span className="hidden xs:inline font-mono">{PAYMENT_CONFIG.whatsappNumber}</span>
              <span className="xs:hidden">Support</span>
            </a>

            {/* Admin Switcher */}
            <button
              onClick={() => setActiveTab('admin')}
              title="Admin Portal"
              className={`p-2 rounded-lg border transition-all relative ${
                activeTab === 'admin'
                  ? 'bg-purple-600/20 border-purple-500 text-purple-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <UserCog className="w-5 h-5" />
              {pendingCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {pendingCount}
                </span>
              )}
            </button>
          </div>

        </div>

        {/* Mobile Sub Navigation */}
        <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800/80">
          <button
            onClick={() => setActiveTab('shop')}
            className={`flex-1 py-1.5 text-center text-xs font-semibold rounded ${
              activeTab === 'shop' ? 'text-orange-400 bg-slate-800/50' : 'text-slate-400'
            }`}
          >
            💎 TopUp Shop
          </button>
          <button
            onClick={() => setActiveTab('track')}
            className={`flex-1 py-1.5 text-center text-xs font-semibold rounded ${
              activeTab === 'track' ? 'text-orange-400 bg-slate-800/50' : 'text-slate-400'
            }`}
          >
            🔍 Track Order
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`flex-1 py-1.5 text-center text-xs font-semibold rounded ${
              activeTab === 'reviews' ? 'text-orange-400 bg-slate-800/50' : 'text-slate-400'
            }`}
          >
            ⭐ Reviews
          </button>
        </div>
      </div>
    </header>
  );
};
