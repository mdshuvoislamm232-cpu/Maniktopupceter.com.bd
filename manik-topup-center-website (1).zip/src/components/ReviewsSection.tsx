import React, { useState } from 'react';
import { Review, INITIAL_REVIEWS } from '../data/packages';
import { Star, MessageSquarePlus, CheckCircle2, User } from 'lucide-react';

export const ReviewsSection: React.FC = () => {
  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('mtc_reviews');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_REVIEWS;
      }
    }
    return INITIAL_REVIEWS;
  });

  const [name, setName] = useState('');
  const [packageBought, setPackageBought] = useState('505 Diamonds');
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(5);
  const [successMsg, setSuccessMsg] = useState(false);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;

    const newReview: Review = {
      id: `rev-${Date.now()}`,
      name: name.trim(),
      rating,
      comment: comment.trim(),
      packageBought,
      date: 'Just now'
    };

    const updated = [newReview, ...reviews];
    setReviews(updated);
    localStorage.setItem('mtc_reviews', JSON.stringify(updated));

    // Reset fields
    setName('');
    setComment('');
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      
      {/* Title */}
      <div className="text-center max-w-xl mx-auto mb-10">
        <h2 className="text-3xl font-black text-white uppercase font-gaming tracking-tight">
          Trusted by Thousands of Gamers
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          Read genuine verification feedback from active players across Bangladesh.
        </p>

        <div className="mt-4 inline-flex items-center gap-1 bg-slate-900 border border-slate-800 px-4 py-1.5 rounded-full text-xs text-amber-400 font-bold">
          <div className="flex gap-0.5">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <span className="text-white ml-1.5">4.9 / 5.0 Average Score</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEAVE A REVIEW FORM */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl sticky top-24">
          <div className="flex items-center gap-2 pb-3 mb-4 border-b border-slate-800">
            <MessageSquarePlus className="w-5 h-5 text-orange-400" />
            <h3 className="font-gaming text-lg font-bold text-white uppercase">Write a Review</h3>
          </div>

          {successMsg && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Review published live instantly! Thank you.</span>
            </div>
          )}

          <form onSubmit={handleSubmitReview} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Your Gamer Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Shakib King FF"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:border-orange-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Package Purchased</label>
              <select
                value={packageBought}
                onChange={(e) => setPackageBought(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:border-orange-500 transition-colors"
              >
                <option value="25 Diamonds">25 Diamonds</option>
                <option value="50 Diamonds">50 Diamonds</option>
                <option value="100 Diamonds">100 Diamonds</option>
                <option value="240 Diamonds">240 Diamonds</option>
                <option value="505 Diamonds">505 Diamonds</option>
                <option value="1080 Diamonds">1080 Diamonds</option>
                <option value="Weekly Membership">Weekly Membership</option>
                <option value="Monthly Membership">Monthly Membership</option>
                <option value="Level Up Pass">Level Up Pass</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Rating</label>
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 focus:outline-none transition-transform hover:scale-110"
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                      }`}
                    />
                  </button>
                ))}
                <span className="text-xs font-bold text-slate-400 ml-2">{rating} Stars</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Your Comment</label>
              <textarea
                required
                rows={3}
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Share your fast top-up experience..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-xs sm:text-sm focus:outline-none focus:border-orange-500 transition-colors resize-none placeholder:text-slate-600"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-slate-950 font-gaming font-bold text-sm tracking-wide uppercase transition-all shadow"
            >
              Post Review
            </button>
          </form>
        </div>


        {/* FEED COLUMN */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Recent Player Testimonials ({reviews.length})
            </span>
            <span className="text-[11px] text-slate-500">Sorted by newest</span>
          </div>

          <div className="space-y-3">
            {reviews.map((rev) => (
              <div
                key={rev.id}
                className="bg-slate-900/60 border border-slate-800 rounded-xl p-4 transition-all hover:bg-slate-900 hover:border-slate-700 text-left"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center shrink-0 border border-slate-700">
                      <User className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-white text-xs sm:text-sm flex items-center gap-1.5">
                        {rev.name}
                        <span title="Verified TopUp Buyer"><CheckCircle2 className="w-3 h-3 text-emerald-400 inline" /></span>
                      </div>
                      <div className="text-[10px] text-orange-400 font-medium">
                        Bought: {rev.packageBought}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-end shrink-0">
                    <div className="flex gap-0.5">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <span className="text-[10px] text-slate-500 mt-1">{rev.date}</span>
                  </div>
                </div>

                <p className="mt-2.5 text-xs sm:text-sm text-slate-300 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>
            ))}
          </div>

        </div>

      </div>

    </div>
  );
};
