import React from 'react';
import { ShieldCheck, Zap, Clock, HelpCircle } from 'lucide-react';
import { PAYMENT_CONFIG } from '../data/packages';

interface HeroProps {
  onScrollToShop: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToShop }) => {
  return (
    <div className="relative overflow-hidden bg-slate-950 border-b border-slate-900">
      {/* Background Image with epic blended overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/images/hero-bg.jpg" 
          alt="Free Fire Arena Background" 
          className="w-full h-full object-cover object-center opacity-30 sm:opacity-40 filter saturate-150"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f19] via-[#0b0f19]/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0b0f19] via-transparent to-[#0b0f19]/90 hidden sm:block" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-16 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Hero Left Content */}
          <div className="lg:col-span-7 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-xs sm:text-sm font-semibold mb-4 backdrop-blur-sm">
              <Zap className="w-4 h-4 fill-current text-amber-400" />
              <span>UID Based Instant Automatic TopUp</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight uppercase font-gaming">
              Free Fire <span className="bg-gradient-to-r from-orange-500 via-amber-400 to-yellow-300 bg-clip-text text-transparent">Diamonds</span> <br className="hidden sm:block" />
              TopUp Center BD
            </h1>

            <p className="mt-4 text-slate-300 text-sm sm:text-base max-w-xl mx-auto lg:mx-0 leading-relaxed font-normal">
              Welcome to <span className="text-white font-bold">Manik TopUp Center</span>. Get your Free Fire Diamonds, Weekly/Monthly Memberships, and Level Up Passes delivered directly to your Player UID in just <strong>2-5 minutes</strong>. Safe, reliable, and authentic!
            </p>

            {/* bKash & WhatsApp Banner Box */}
            <div className="mt-6 p-4 rounded-xl bg-slate-900/90 border border-slate-800 max-w-xl mx-auto lg:mx-0 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#e2136e]/20 flex items-center justify-center font-bold text-[#e2136e] border border-[#e2136e]/30 shrink-0">
                  bK
                </div>
                <div className="text-left">
                  <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wider">bKash Personal Send Money</p>
                  <p className="text-lg font-mono font-bold text-white tracking-wide">{PAYMENT_CONFIG.bkashNumber}</p>
                </div>
              </div>

              <div className="h-8 w-[1px] bg-slate-800 hidden sm:block"></div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center font-bold text-emerald-400 border border-emerald-500/30 shrink-0">
                  WA
                </div>
                <div className="text-left">
                  <p className="text-[11px] text-slate-400 font-medium uppercase tracking-wider">WhatsApp Helpline</p>
                  <p className="text-lg font-mono font-bold text-white tracking-wide">{PAYMENT_CONFIG.whatsappNumber}</p>
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <div className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-4">
              <button
                onClick={onScrollToShop}
                className="px-8 py-4 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-slate-950 font-gaming font-bold text-lg tracking-wider uppercase shadow-lg shadow-orange-600/30 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2 cursor-pointer"
              >
                ⚡ TopUp Now
              </button>
              
              <a
                href="#how-to"
                className="px-6 py-4 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white font-gaming font-semibold text-base tracking-wide border border-slate-800 transition-all flex items-center gap-2"
              >
                <HelpCircle className="w-4 h-4 text-slate-400" /> How to Order?
              </a>
            </div>

          </div>

          {/* Hero Right Featured Badges */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm lg:max-w-none">
              <div className="absolute -inset-1 rounded-3xl bg-gradient-to-tr from-orange-600 to-amber-400 opacity-20 blur-xl"></div>
              
              <div className="relative rounded-2xl bg-slate-900/80 border border-slate-800/80 p-6 backdrop-blur-sm shadow-2xl">
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <span className="text-xs font-bold uppercase tracking-widest text-slate-400">Live Delivery Metrics</span>
                  <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span> Systems Online
                  </span>
                </div>

                <div className="mt-5 space-y-4">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-lg bg-orange-500/10 text-orange-400 mt-0.5">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Super Fast Fulfillment</h4>
                      <p className="text-xs text-slate-400 mt-0.5">Orders processed automatically within 2-5 minutes of bKash confirmation.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-lg bg-emerald-500/10 text-emerald-400 mt-0.5">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">100% Genuine Diamonds</h4>
                      <p className="text-xs text-slate-400 mt-0.5">Direct partnership transfer via official UID channel. Zero ban risks.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-lg bg-blue-500/10 text-blue-400 mt-0.5">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Easy bKash Checkout</h4>
                      <p className="text-xs text-slate-400 mt-0.5">Simply transfer amount to 01335988524 and input TrxID to claim instantly.</p>
                    </div>
                  </div>
                </div>

                {/* Micro trust widget */}
                <div className="mt-6 pt-4 border-t border-slate-800/60 bg-slate-950/40 -mx-6 -mb-6 p-4 rounded-b-2xl flex items-center justify-around text-center">
                  <div>
                    <span className="block font-gaming text-lg font-bold text-amber-400">45k+</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Gamers Served</span>
                  </div>
                  <div className="w-[1px] h-6 bg-slate-800"></div>
                  <div>
                    <span className="block font-gaming text-lg font-bold text-white">4.9 ★</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Satisfaction Rating</span>
                  </div>
                  <div className="w-[1px] h-6 bg-slate-800"></div>
                  <div>
                    <span className="block font-gaming text-lg font-bold text-emerald-400">100%</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Secure TopUp</span>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
