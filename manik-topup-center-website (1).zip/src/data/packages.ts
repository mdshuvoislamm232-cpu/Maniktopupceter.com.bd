export interface TopupPackage {
  id: string;
  name: string;
  diamonds: number;
  bonus?: number;
  price: number; // in BDT
  category: 'diamonds' | 'membership' | 'special';
  tag?: string;
  iconType?: 'diamond' | 'card' | 'gift';
}

export const TOPUP_PACKAGES: TopupPackage[] = [
  // Diamonds
  { id: 'ff-25', name: '25 Diamonds', diamonds: 25, price: 25, category: 'diamonds', iconType: 'diamond' },
  { id: 'ff-50', name: '50 Diamonds', diamonds: 50, price: 45, category: 'diamonds', iconType: 'diamond' },
  { id: 'ff-100', name: '100 Diamonds', diamonds: 100, price: 85, category: 'diamonds', tag: 'Popular', iconType: 'diamond' },
  { id: 'ff-115', name: '115 Diamonds', diamonds: 115, bonus: 10, price: 95, category: 'diamonds', iconType: 'diamond' },
  { id: 'ff-240', name: '240 Diamonds', diamonds: 240, bonus: 20, price: 190, category: 'diamonds', tag: 'Best Seller', iconType: 'diamond' },
  { id: 'ff-355', name: '355 Diamonds', diamonds: 355, bonus: 35, price: 285, category: 'diamonds', iconType: 'diamond' },
  { id: 'ff-505', name: '505 Diamonds', diamonds: 505, bonus: 50, price: 400, category: 'diamonds', tag: 'Hot Deal', iconType: 'diamond' },
  { id: 'ff-1080', name: '1080 Diamonds', diamonds: 1080, bonus: 108, price: 850, category: 'diamonds', iconType: 'diamond' },
  { id: 'ff-2200', name: '2200 Diamonds', diamonds: 2200, bonus: 220, price: 1700, category: 'diamonds', tag: 'Mega Saver', iconType: 'diamond' },
  { id: 'ff-5600', name: '5600 Diamonds', diamonds: 5600, bonus: 600, price: 4300, category: 'diamonds', iconType: 'diamond' },

  // Memberships
  { id: 'ff-week', name: 'Weekly Membership', diamonds: 450, price: 165, category: 'membership', tag: 'Instant VIP', iconType: 'card' },
  { id: 'ff-month', name: 'Monthly Membership', diamonds: 2600, price: 850, category: 'membership', tag: '2600💎 Total', iconType: 'card' },
  { id: 'ff-both', name: 'Weekly + Monthly Combo', diamonds: 3100, price: 1000, category: 'membership', tag: 'Super Combo', iconType: 'card' },

  // Special Passes
  { id: 'ff-level', name: 'Level Up Pass', diamonds: 800, price: 160, category: 'special', tag: 'One Time Only', iconType: 'gift' },
  { id: 'ff-airdrop-1', name: 'Special Airdrop (৳90)', diamonds: 300, price: 90, category: 'special', iconType: 'gift' },
  { id: 'ff-airdrop-2', name: 'Special Airdrop (৳180)', diamonds: 600, price: 180, category: 'special', iconType: 'gift' },
];

export interface Order {
  orderId: string;
  uid: string;
  packageId: string;
  packageName: string;
  price: number;
  paymentMethod: 'bKash' | 'WhatsApp';
  senderNumber: string;
  trxId: string;
  status: 'Pending' | 'Processing' | 'Completed' | 'Rejected';
  timestamp: string;
  note?: string;
}

export const INITIAL_ORDERS: Order[] = [
  {
    orderId: 'MTC-9831',
    uid: '7482910385',
    packageId: 'ff-240',
    packageName: '240 Diamonds',
    price: 190,
    paymentMethod: 'bKash',
    senderNumber: '01711234567',
    trxId: 'BKS9A8F7E2B',
    status: 'Completed',
    timestamp: new Date(Date.now() - 15 * 60000).toLocaleString(),
  },
  {
    orderId: 'MTC-9842',
    uid: '1928374650',
    packageId: 'ff-week',
    packageName: 'Weekly Membership',
    price: 165,
    paymentMethod: 'bKash',
    senderNumber: '01822345678',
    trxId: 'BKS7C6D5E4A',
    status: 'Processing',
    timestamp: new Date(Date.now() - 5 * 60000).toLocaleString(),
  },
  {
    orderId: 'MTC-9850',
    uid: '4563829102',
    packageId: 'ff-100',
    packageName: '100 Diamonds',
    price: 85,
    paymentMethod: 'bKash',
    senderNumber: '01933456789',
    trxId: 'BKS3B2A1F0E',
    status: 'Pending',
    timestamp: new Date(Date.now() - 1 * 60000).toLocaleString(),
  }
];

export interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  packageBought: string;
  date: string;
}

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    name: 'Shakib Gamer X',
    rating: 5,
    comment: 'Thanks Manik Bhai! Top up fast within 2 minutes. bKash payment simple.',
    packageBought: 'Weekly Membership',
    date: 'Today'
  },
  {
    id: 'rev-2',
    name: 'Rakib FF Pro',
    rating: 5,
    comment: '100% trusted site. Send money to 01335988524 and got 505 Diamonds immediately.',
    packageBought: '505 Diamonds',
    date: 'Yesterday'
  },
  {
    id: 'rev-3',
    name: 'Nusrat Jahan',
    rating: 5,
    comment: 'Best ID code topup center in BD. Responsive on WhatsApp too.',
    packageBought: 'Level Up Pass',
    date: 'Yesterday'
  },
  {
    id: 'rev-4',
    name: 'Tanim King',
    rating: 5,
    comment: 'Highly recommended Manik TopUp Center! Cheap price and secure.',
    packageBought: '1080 Diamonds',
    date: '2 days ago'
  }
];

export const PAYMENT_CONFIG = {
  bkashNumber: '01335988524',
  whatsappNumber: '01335988524',
  whatsappUrl: 'https://wa.me/8801335988524',
  deliveryTime: '2 - 5 Minutes',
};
